#define CURRENT_FIRMWARE_VERSION "0.0.1"
//### WARNING ### Do Not Change the line above or builds will fail
#define DEVICE_TYPE "connhome-smartpixels"